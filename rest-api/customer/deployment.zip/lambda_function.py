import os, json
from pymongo import MongoClient


client = MongoClient(host=os.environ.get("mongodb+srv://rishiagl:<password>@v0.bvowwjb.mongodb.net/?retryWrites=true&w=majority&appName=V0"))


def lambda_handler(event, context):
    # Name of database
    db = client.test 

    # Name of collection
    collection = db.Customer 
    
    cursor = collection.find({})
    
    customers = []
    
    for doc in cursor:
        customers.append(doc)


    return json.dumps(customers)
    